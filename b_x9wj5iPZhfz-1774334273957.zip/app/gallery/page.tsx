import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FloatingChatButton } from '@/components/floating-chat-button'

export default function GalleryPage() {
  const images = [
    { id: 1, title: 'Rừng Xanh', category: 'Thiên Nhiên', emoji: '🌲' },
    { id: 2, title: 'Đại Dương Sạch', category: 'Nước', emoji: '🌊' },
    { id: 3, title: 'Năng Lượng Tái Tạo', category: 'Năng Lượng', emoji: '☀️' },
    { id: 4, title: 'Cây Xanh Trong Thành Phố', category: 'Không Khí', emoji: '🌿' },
    { id: 5, title: 'Động Vật Hoang Dã', category: 'Sinh Học', emoji: '🦁' },
    { id: 6, title: 'Thế Hệ Xanh', category: 'Cộng Đồng', emoji: '👨‍👩‍👧‍👦' },
    { id: 7, title: 'Tái Chế', category: 'Chất Thải', emoji: '♻️' },
    { id: 8, title: 'Trái Đất', category: 'Hành Tinh', emoji: '🌍' },
    { id: 9, title: 'Nông Nghiệp Bền Vững', category: 'Thực Phẩm', emoji: '🚜' },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Thư Viện Hình Ảnh</h1>
          <p className="text-lg text-gray-600 mb-12 max-w-2xl text-pretty">
            Khám phá những hình ảnh đẹp về thiên nhiên, các dự án bảo vệ môi trường, và cảm hứng cho sống xanh.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image) => (
              <div
                key={image.id}
                className="group relative bg-white rounded-lg overflow-hidden border-2 border-gray-200 hover:border-primary hover:shadow-lg transition-all cursor-pointer"
              >
                <div className="aspect-square bg-gradient-to-br from-green-100 to-blue-100 flex items-center justify-center overflow-hidden relative">
                  <div className="text-7xl group-hover:scale-110 transition-transform duration-300">
                    {image.emoji}
                  </div>
                </div>
                <div className="p-4">
                  <div className="inline-block px-3 py-1 bg-secondary text-primary rounded-full text-xs font-semibold mb-2">
                    {image.category}
                  </div>
                  <h3 className="text-lg font-bold text-primary">{image.title}</h3>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-secondary rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-primary mb-4">Chia Sẻ Câu Chuyện Của Bạn</h2>
            <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
              Bạn có những hình ảnh hoặc câu chuyện về sống xanh muốn chia sẻ? Chúng tôi rất muốn nghe từ bạn! Liên hệ với chúng tôi để chia sẻ câu chuyện của bạn.
            </p>
            <a
              href="/contact"
              className="inline-block px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-accent transition-colors"
            >
              Liên Hệ Với Chúng Tôi
            </a>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingChatButton />
    </div>
  )
}
