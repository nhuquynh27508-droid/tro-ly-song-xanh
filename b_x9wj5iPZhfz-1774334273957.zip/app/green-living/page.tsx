import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { FloatingChatButton } from '@/components/floating-chat-button'

export default function GreenLivingPage() {
  const tips = [
    {
      category: 'Năng Lượng',
      icon: '⚡',
      items: [
        'Sử dụng đèn LED để tiết kiệm điện lên đến 75%',
        'Cách nhiệt nhà của bạn để giảm chi phí sưởi ấm',
        'Sử dụng các thiết bị tiết kiệm năng lượng',
        'Tắt thiết bị khi không sử dụng',
      ],
    },
    {
      category: 'Nước',
      icon: '💧',
      items: [
        'Giảm thời gian tắm xuống 5 phút để tiết kiệm nước',
        'Sửa chữa những vòi nước bị rò rỉ',
        'Sử dụng máy rửa bát thay vì rửa bằng tay',
        'Thu gom nước mưa để tưới cây',
      ],
    },
    {
      category: 'Vận Chuyển',
      icon: '🚴',
      items: [
        'Đi bộ hoặc đạp xe cho những chuyến đi ngắn',
        'Sử dụng giao thông công cộng để giảm khí thải',
        'Chia sẻ xe với bạn bè và đồng nghiệp',
        'Nâng cấp lên xe điện nếu có thể',
      ],
    },
    {
      category: 'Thực Phẩm',
      icon: '🥬',
      items: [
        'Ăn ít thịt và chọn thực phẩm có nguồn gốc địa phương',
        'Mua thực phẩm hữu cơ không sử dụng thuốc trừ sâu',
        'Giảm lãng phí thực phẩm bằng cách lên kế hoạch bữa ăn',
        'Trồng rau và cây cảnh tại nhà',
      ],
    },
    {
      category: 'Giảm Chất Thải',
      icon: '♻️',
      items: [
        'Sử dụng lại các mặt hàng trước khi vứt bỏ',
        'Tái chế giấy, nhựa, kim loại và thủy tinh',
        'Sử dụng túi tái sử dụng thay vì túi nhựa',
        'Mua sản phẩm có bao bì tối thiểu',
      ],
    },
    {
      category: 'Mua Sắm',
      icon: '🛍️',
      items: [
        'Chọn sản phẩm được sản xuất bền vững',
        'Mua hàng cũ hoặc các sản phẩm tân trang',
        'Hỗ trợ các công ty có trách nhiệm với môi trường',
        'Mua ít nhưng chọn chất lượng cao',
      ],
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-8">Sống Xanh</h1>

          <div className="bg-gradient-to-r from-primary to-accent text-white rounded-lg p-8 mb-12">
            <h2 className="text-2xl font-bold mb-4">🌱 Hành Động Nhỏ, Tác Động Lớn</h2>
            <p className="text-lg leading-relaxed">
              Sống xanh không nhất thiết phải hoàn hảo. Bằng cách thực hiện những thay đổi nhỏ trong cuộc sống hàng ngày của bạn, bạn có thể giúp bảo vệ môi trường và tạo ra một tương lai bền vững. Bắt đầu hôm nay với những mẹo của chúng tôi!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tips.map((tip, index) => (
              <div key={index} className="bg-white rounded-lg border-2 border-gray-200 overflow-hidden hover:border-primary hover:shadow-lg transition-all">
                <div className="bg-secondary p-4 border-b-2 border-gray-200">
                  <div className="text-4xl mb-2">{tip.icon}</div>
                  <h3 className="text-xl font-bold text-primary">{tip.category}</h3>
                </div>
                <ul className="p-4 space-y-3">
                  {tip.items.map((item, idx) => (
                    <li key={idx} className="flex gap-3">
                      <span className="text-primary font-bold flex-shrink-0">✓</span>
                      <span className="text-gray-700 text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-white border-l-4 border-primary p-8 rounded">
            <h2 className="text-2xl font-bold text-primary mb-4">Các Biện Pháp Bảo Vệ Môi Trường Lớn Hơn</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-primary mb-2">Mức Cá Nhân:</h4>
                <ul className="list-disc pl-6 text-gray-700 space-y-2">
                  <li>Giáo dục chính mình và gia đình về bền vững</li>
                  <li>Tham gia các tổ chức bảo vệ môi trường</li>
                  <li>Lên tiếng về các vấn đề môi trường</li>
                  <li>Ủng hộ các chính sách bảo vệ môi trường</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-primary mb-2">Mức Cộng Đồng:</h4>
                <ul className="list-disc pl-6 text-gray-700 space-y-2">
                  <li>Tổ chức các sự kiện trồng cây và dọn dẹp</li>
                  <li>Ủng hộ các doanh nghiệp bền vững địa phương</li>
                  <li>Xây dựng khu vườn cộng đồng</li>
                  <li>Thúc đẩy các chính sách bảo vệ môi trường</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <FloatingChatButton />
    </div>
  )
}
